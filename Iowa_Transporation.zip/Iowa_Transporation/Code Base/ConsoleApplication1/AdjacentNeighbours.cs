﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace IowaTransporation
{
    public class AdjacentNeibours
    {

        public bool GetAdjNeibours(int a, int b)
        {
            using (SqlConnection connection = new SqlConnection(@"Data Source=LAPTOP-8FFU8JEE;Initial Catalog=CryptoArb;Integrated Security=True"))
            {
                bool result = false;
                SqlCommand scCommand = new SqlCommand("get_county_code", connection);
                scCommand.CommandType = CommandType.StoredProcedure;
                scCommand.Parameters.AddWithValue("@input_county", a);
                scCommand.Parameters.AddWithValue("@near_county", b);
                scCommand.Parameters.Add("@Result", SqlDbType.Bit).Direction = ParameterDirection.Output;
                try
                {
                    if (scCommand.Connection.State == ConnectionState.Closed)
                    {
                        scCommand.Connection.Open();
                    }
                    scCommand.ExecuteNonQuery();
                    result = Convert.ToBoolean(scCommand.Parameters["@Result"].Value);
                    scCommand.Connection.Close();

                }
                catch (Exception ex)
                {
                    Console.WriteLine("\nMessage ---\n{0}", ex.Message);
                    scCommand.Connection.Close();
                }
                Console.WriteLine("Are the two counties adjacent: " + result);
                return result;
            }
        }
    }
}
