﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IowaTransporation
{
    class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Enter the County number");
            int a;
            while (!int.TryParse(Console.ReadLine(), out a))
            {
                Console.WriteLine("Please Enter a valid numerical value!");
            }
            Console.WriteLine("Enter the Adjacent County number");
            int b;
            while (!int.TryParse(Console.ReadLine(), out b))
            {
                Console.WriteLine("Please Enter a valid numerical value!");
            }
            AdjacentNeibours adjNeibours = new AdjacentNeibours();
            adjNeibours.GetAdjNeibours(a, b);
            Console.ReadLine();
        }
    }
}
