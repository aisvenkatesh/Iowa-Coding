
CREATE TABLE [dbo].[COUNTY](
	[ID] [int] NULL,
	[COUNTY_NO] [int] NULL,
	[ADJ_COUNTY_1] [int] NULL,
	[ADJ_COUNTY_2] [int] NULL,
	[ADJ_COUNTY_3] [int] NULL,
	[ADJ_COUNTY_4] [int] NULL,
	[ADJ_COUNTY_5] [int] NULL,
	[ADJ_COUNTY_6] [int] NULL,
	[ADJ_COUNTY_7] [int] NULL,
	[ADJ_COUNTY_8] [int] NULL
) ON [PRIMARY]

GO


