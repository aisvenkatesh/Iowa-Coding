IF EXISTS(SELECT 1 FROM sys.procedures 
          WHERE Name = 'get_county_code')
BEGIN
    DROP PROCEDURE dbo.get_county_code
END
GO

CREATE PROCEDURE [dbo].[get_county_code]
  ( @input_county int, 
@near_county int,
@Result bit output)
 AS 
BEGIN 

IF EXISTS (SELECT * FROM COUNTY WHERE  COUNTY_no=@input_county AND  @near_county in (adj_county_1, adj_county_2, adj_county_3, adj_county_4, adj_county_5,adj_county_6, adj_county_7, adj_county_8))

 Begin 
 Set @Result=1; 
End
ELSE
Begin
 
Set @Result=0;
 End

END
